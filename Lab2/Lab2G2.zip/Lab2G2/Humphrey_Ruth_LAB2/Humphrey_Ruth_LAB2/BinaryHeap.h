#pragma once 
using namespace std;
#include<iostream>
#include<climits>
#include "DynArray.h"
using namespace std;

template<typename Type>

class BinaryHeap : public DynArray <int>
{

public:


	int parent(int i) { return (i - 1) / 2; }
	int left(int i) { return (2 * i + 1); }
	int right(int i) { return (2 * i + 2); }

	/////////////////////////////////////////////////////////////////////////////
	// Function : enqueue
	// Parameters : v - the item to add to the heap
	// Notes : after the new item is added, this function ensures that the 
	//	smallest value in the heap is in [0]
	/////////////////////////////////////////////////////////////////////////////
	void enqueue(const Type &v)
	{
		append(v);

		int current = Size - 1;

		while (array[parent(current)] > array[current])
		{
			swap(array[current], array[parent(current)]);
		}

	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : dequeue 
	// Return : the item that was located at [0]
	// Notes : after the smallest item is dequeued, this function ensures that 
	//	the smallest item is in [0]. DynArray may need to be modified to change
	//	Size's access type to protected so it can be decremented here
	/////////////////////////////////////////////////////////////////////////////
	Type dequeue()
	{
		Type tempTop = array[0]; 

		Type highest = array[Size - 1];

		tempTop = highest;

		Size = Size - 1;

		int current = Size - 1;
		
		while (array[parent(current)] > array[current])
		{
			swap(array[current], array[parent(current)]);
		}

		return tempTop;
	}

	///////////////////////////////////////////////////////////////////////////////
	// Function : operator[]
	// Parameters : index - the index to access
	// Return : Type& - the item in the index
	// Notes: calls parent operator[]
	/////////////////////////////////////////////////////////////////////////////
	Type& operator[](int index)
	{
		parent(index);

		return array[index];
	}

	/////////////////////////////////////////////////////////////////////////////
	//// Function : clear	
	//// Notes : calls parent clear()
	///////////////////////////////////////////////////////////////////////////////
	//void clear()
	//{
	//	
	//}


	/////////////////////////////////////////////////////////////////////////////////
	//// Function : size
	//// Return : the number of valid items in the heap
	//// Notes: calls parent size()
	///////////////////////////////////////////////////////////////////////////////
	//unsigned int size()
	//{

	//}

};
