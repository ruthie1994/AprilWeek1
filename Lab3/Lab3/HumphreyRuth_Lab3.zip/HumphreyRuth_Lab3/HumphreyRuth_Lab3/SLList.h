#pragma once

// forward declaration
template<typename Type> class SLLIter;

// class SLList
template<typename Type> 
class SLList
{
	// the iterator is the list�s friend
	friend class SLLIter<Type>;

	// add members/methods here�
private:
	Node* head = nullptr;
	unsigned int Size = 0;

	friend class SLLIter<Type>;

public:

	/////////////////////////////////////////////////////////////////////////////
	// Function : Constructor
	// Notes : Does nothing because members were initialized above.
	//		Still needs to exist due to copy constructor
	/////////////////////////////////////////////////////////////////////////////
	SLList()
	{

	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : Destructor
	// Notes : Destroys the list (call clear())
	/////////////////////////////////////////////////////////////////////////////
	~SLList()
	{
		clear();
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : Assignment Operator
	// Notes: Performs a deep copy of that list. HINT: Much easier to do via
	//		recursion. Make a helper function that calls addHead() as the
	//		stack unwinds (meaning it happens backwards).
	/////////////////////////////////////////////////////////////////////////////
	SLList<Type>& operator=(const SLList<Type>& that)
	{
		clear();

		Node newNode = new Node;

		data = that.data;
		next = that.next;
		size = that.size;

		for (int i = 0; i < Size; i++)
		{
			newNode = that.newNode;
			addHead(newNode);
		}

		return *this;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : Copy Constructor
	// Notes:	Calls the assignment operator.
	/////////////////////////////////////////////////////////////////////////////
	SLList(const SLList<Type>& that)
	{
		clear();

		Node newNode = new Node;

		data = that.data;
		next = that.next;
		size = that.size;

		for (int i = 0; i < Size; i++)
		{
			newNode = that.newNode;
			addHead(newNode);
		}

		return *this;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : addHead
	// Parameters :	v - the item to add to the front of the list
	/////////////////////////////////////////////////////////////////////////////
	void addHead(const Type& v)
	{
		Node* newNode = new Node;
		newNode->curr = v;
		newNode->next = head;
		head = newNode;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : clear
	// Notes : clears the list, freeing any dynamic memory
	/////////////////////////////////////////////////////////////////////////////
	void clear()
	{
		while (head == NULL)
		{
			Node* curr = head;
			head = curr->next;
			delete curr;
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : insert
	// Parameters :	index - an iterator pointing at the location to insert at
	//				v - the item to insert
	// Notes : The new node should be inserted to the left of index's current
	//		pointer. Do nothing if index's current pointer is null
	/////////////////////////////////////////////////////////////////////////////
	void insert(SLLIter<Type>& index, const Type& v)
	{
		Node current = new Node;
		current->data = index;

		Node temp = new Node;
		temp->data = v;

		Node prev = new Node;

		current = head;
		for (int i = 1; i < index; i++)
		{
			prev = current;
			current = current->next;
		}

		prev->next = temp;
		temp->next = current;

	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : remove
	// Parameters :	index - an iterator pointing at the node to be deleted
	// Notes : Do nothing if index's current pointer is null
	/////////////////////////////////////////////////////////////////////////////
	void remove(SLLIter<Type>& index)
	{
		Node current = new Node;
		current->data = index;

		Node prev = new Node;

		current = head;
		for (int i = 1; i < index; i++)
		{
			prev = current;
			current = current->next;
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : size
	// Return : the number of items stored in the linked list.
	/////////////////////////////////////////////////////////////////////////////
	const unsigned int size()
	{
		return Size;
	}
};


template<typename Type>

class SLLIter
{
	// the list is the iterator�s friend
	friend class SLList<Type>;

	// add members/methods here�
private:
	SLList<Type>* ptrList;
	typename SLList<Type>::Node * curr;
	typename SLList<Type>::Node * prev;

	friend class SLList<Type>;

public:
	/////////////////////////////////////////////////////////////////////////////
	// Function : Constructor
	// Parameters :	listToIterate - the list to iterate
	// Notes: Set your list pointer to point at this list's address
	/////////////////////////////////////////////////////////////////////////////
	SLLIter(SLList<Type>& listToIterate)
	{
		ptrList = &listToIterate;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : begin
	// Notes : moves the iterator to the head of the list you are pointing at
	/////////////////////////////////////////////////////////////////////////////
	void begin()
	{
		curr = head;

	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : end
	// Notes : return true if current is null. False otherwise 
	/////////////////////////////////////////////////////////////////////////////
	bool end() const
	{
		if (curr = NULL)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : operator++
	// Notes : Move the current pointer to its own next
	/////////////////////////////////////////////////////////////////////////////
	SLLIter<Type>& operator++()
	{
		curr = curr->next;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : current
	// Notes : returns the item at the current iterator location. Does not
	//		perform error checking
	/////////////////////////////////////////////////////////////////////////////
	Type& current() const
	{
		return curr;
	}
};