#pragma once

template<typename Type>

class BST
{
private:
	struct Node 
	{
		Node* root = nullptr;
	};
	
public:
	/////////////////////////////////////////////////////////////////////////////
	// Function : Constuctor
	// Notes : does nothing
	/////////////////////////////////////////////////////////////////////////////
	BST()
	{

	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : Destructor
	// Notes : deletes each node in the tree recursively
	/////////////////////////////////////////////////////////////////////////////
	~BST()
	{
		/*Node *root = new Node;*/

		struct Node* deleteNode(struct Node*root, Type key)
		{
			// base case 
			if (root == NULL) return root;

			// If the key to be deleted is smaller than the root's key, 
			// then it lies in left subtree 
			if (key < root->key)
				root->left = deleteNode(root->left, key);

			// If the key to be deleted is greater than the root's key, 
			// then it lies in right subtree 
			else if (key > root->key)
				root->right = deleteNode(root->right, key);

			// if key is same as root's key, then This is the node 
			// to be deleted 
			else
			{
				// node with only one child or no child 
				if (root->left == NULL)
				{
					struct node *temp = root->right;
					free(root);
					return temp;
				}
				else if (root->right == NULL)
				{
					struct node *temp = root->left;
					free(root);
					return temp;
				}

				// node with two children: Get the inorder successor (smallest 
				// in the right subtree) 
				struct node* temp = minValueNode(root->right);

				// Copy the inorder successor's content to this node 
				root->key = temp->key;

				// Delete the inorder successor 
				root->right = deleteNode(root->right, temp->key);
			}
			return root;
		}
	}
	/////////////////////////////////////////////////////////////////////////////
	// Function : assignment operator
	// Notes: Deep copy of that tree. Starting at that root, recursively
	//		call insert in a helper function
	/////////////////////////////////////////////////////////////////////////////
	BST& operator=(const BST& that);

	/////////////////////////////////////////////////////////////////////////////
	// Function: copy constructor
	// Notes:	call assignment operator
	/////////////////////////////////////////////////////////////////////////////
	BST(const BST& that);

	/////////////////////////////////////////////////////////////////////////////
	// Function : insert
	// Parameters :  v - the item to insert into the tree 
	/////////////////////////////////////////////////////////////////////////////
	void insert(const Type& v)
	{
		if (Node == NULL)
		{
			Node newKey = new Node;
			return newKey;
		}

		if (v < Node->newKey)
		{
			Node->left = insert(Node->left, newKey);
		}
		else if (newKey > Node->newKey)
		{
			Node->right = insert(Node->right, newKey);
		}

		return Node;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : findAndRemove
	// Parameters : v - the item to find (and remove if it is found)
	// Return : bool - true if the item was removed, false otherwise
	// Notes: Find the correct node first, then children cases:
	//		A) 2 children ("fix" tree)
	//		B) 0 children
	//		C) 1 children
	/////////////////////////////////////////////////////////////////////////////
	bool findAndRemove(const Type& v)
	{
		if (root == NULL || root->v == v)
		{
			deleteNode(root, v);
			return root;
		}

		if (root->v < v)
		{
			if (search(root->right, key))
			{
				deleteNode(root, v);
				return true ;
			}
			else
			{
				return false;
			}
		}

		if (root->v < v)
		{
			if (search(root->left, key))
			{
				deleteNode(root, v);
				return true;
			}
			else
			{
				return false;
			}
		}

	}




	/////////////////////////////////////////////////////////////////////////////
	// Function : find
	// Parameters : v - the item to find
	// Return : bool - true if the item was found, false otherwise
	// Notes: Does not need to be recursive
	/////////////////////////////////////////////////////////////////////////////
	bool find(const Type& v) const
	{
		if (root == NULL || root->key == key)
		{
			return root;
		}

		if (root->key < key)
		{
			return search(root->right, key);
		}

		return search(root->left, key);
	}


	/////////////////////////////////////////////////////////////////////////////
	// Function : clear
	// Notes : Make helper function to recursively delete each node in a
	//		post-order
	/////////////////////////////////////////////////////////////////////////////
	void clear()
	{
		if (root == NULL)
		{
			return;
		}

		clear(node->left);
		clear(node->right);

		free(node);
	}

	/////////////////////////////////////////////////////////////////////////////
	// Function : printInOrder
	// Notes : prints the contents of the BST to the screen, in ascending order
	//		using resursive helper function
	/////////////////////////////////////////////////////////////////////////////
	void printInOrder() const
	{
		
	}


};